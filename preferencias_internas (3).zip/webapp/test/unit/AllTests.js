sap.ui.define([
	"maz_renfe/preferencias_internas/test/unit/controller/MainView.controller"
], function () {
	"use strict";
});