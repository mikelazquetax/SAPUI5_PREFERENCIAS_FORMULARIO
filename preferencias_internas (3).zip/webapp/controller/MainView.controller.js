sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox",
	"sap/ui/core/Fragment",
], function (Controller, MessageBox, Fragment) {
	"use strict";
	var pathJR = '/odata/v2/JobRequisition';
	var pathPREF = '/ZrcmgrabarpreferenciasSet'
	var jobTitle;
	var arrayPlazasOriginales = [{
		"PLAZA": "",
		"NPLAZAS": ""
	}];
	return Controller.extend("maz_renfe.preferencias_internas.controller.MainView", {
		onInit: function () {

			//Modelo para controlar la visibilidad de los botones guardar y añadir
			var oJSONModelVisibilidad = new sap.ui.model.json.JSONModel({
				visibleBtnAdd: false,
				visibleBtnSave: false
			});
			//Bindeamos el objeto modelo JSON de visibilidad de botones en la vista
			this.getView().setModel(oJSONModelVisibilidad, "jsonVisibilidad");
			//Modelo para mostrar el nombre de la convocatoria.
			var oJSONModelTextoConvocatoria = new sap.ui.model.json.JSONModel({
				texto: "",
			});
			this.getView().setModel(oJSONModelTextoConvocatoria, "jsonTitulo");

		},

		onChange: function (evento) {
			//Funcion que se ejecuta cada vez que hay un cambio en el campo "identificador convocatoria"
			this.getView().byId("descripcion").setValue("")
			this.getView().byId("DRS2").setValue("")
			this.getView().byId("min").setValue("")
			this.getView().byId("max").setValue("")
			var data = []

			var oModelNew = new sap.ui.model.json.JSONModel();
			oModelNew.setData(data);

			this.getView().setModel(oModelNew, "jsonSELPREF");

			var jobReqId = '(' + evento.getParameters().value + 'L)';
			var that = this;
			$.ajax({
				url: pathJR + jobReqId,
				type: "GET",
				dataType: "json",
				headers: {
					"DataServiceVersion": "2.0",
					"X-CSRF-Token": "Fetch",
					"Content-Type": "application/json; charset=utf-8"
				},
				async: true,
				success: function (result, status, response) {

					if (result.d.templateId == '446' || result.d.templateId == '503') { //Si se encuentra la convocatoria y es de movilidad interna
					//1. se visualizan los botones.
					//2. se recupera el nombre en español de la convocatoria - getNames.
					//3. Se inicializa, si lo hubiera, lo guardado previamente en Base de datos.
						//	MessageBox.success('Convocatoria Interna');
						var datosVisibilidad = that.getView().getModel("jsonVisibilidad").getData();
						datosVisibilidad.visibleBtnAdd = true;
						datosVisibilidad.visibleBtnSave = true;
						that.getView().getModel("jsonVisibilidad").setData(datosVisibilidad);

						that.getNames(jobReqId).then(function (apto) { 
							if (apto) {
								var datosTitulo = that.getView().getModel("jsonTitulo").getData();
								datosTitulo.texto = 'Convocatoria: ' + apto
								that.getView().getModel("jsonTitulo").setData(datosTitulo)

								that.readDataBaseInitialize()

							} else {
								return
							}
						})

					} else {
						MessageBox.error('Convocatoria No Elegible: No es una Convocatoria Interna');
						datosVisibilidad = that.getView().getModel("jsonVisibilidad").getData();
						datosVisibilidad.visibleBtnAdd = false;
						datosVisibilidad.visibleBtnSave = false;

						that.getView().getModel("jsonVisibilidad").setData(datosVisibilidad);

						var datosTitulo = that.getView().getModel("jsonTitulo").getData();
						datosTitulo.texto = "Sin Texto"
						that.getView().getModel("jsonTitulo").setData(datosTitulo)
					}
				},
				error: function (oError) {
					if (jobReqId.length == 7) {
						MessageBox.error('NO existe ninguna convocatoria con ese identificador')
					};
					var datosVisibilidad = that.getView().getModel("jsonVisibilidad").getData();
					datosVisibilidad.visibleBtnAdd = false;
					datosVisibilidad.visibleBtnSave = false;

					that.getView().getModel("jsonVisibilidad").setData(datosVisibilidad);

					var datosTitulo = that.getView().getModel("jsonTitulo").getData();
					datosTitulo.texto = "Sin Texto"
					that.getView().getModel("jsonTitulo").setData(datosTitulo)

				}
			});

		},

		getNames: async function (jobReqId) {
			//Funcion para obtener nombre CONVOCATORIA
			return new Promise((resolve, reject) => {
				$.ajax({
					url: pathJR + jobReqId + '/jobReqLocale',
					type: "GET",
					dataType: "json",
					headers: {
						"DataServiceVersion": "2.0",
						"X-CSRF-Token": "Fetch",
						"Content-Type": "application/json; charset=utf-8"
					},
					async: true,
					success: function (result, status, response) {
						jobTitle = result.d.results[0].jobTitle
						resolve(jobTitle)
					},
					error: function (oError) {
						resolve(false)
					}

				})
			})
		},

		addPreference: function () {
			var oView = this.getView();
			var that = this
			var resultado
			this.preferencias().then(function (apto) {
				resultado = apto
				if (!that._pValueHelpDialog) {
					that._pValueHelpDialog = Fragment.load({
						id: oView.getId(),
						name: "maz_renfe.preferencias_internas.fragment.ValueHelpDialog",
						controller: that
					}).then(function (oValueHelpDialog, apto) {
						oView.addDependent(oValueHelpDialog);
						return oValueHelpDialog;
					});
				}
				that._pValueHelpDialog.then(function (oValueHelpDialog, apto) {
					//	that._configValueHelpDialog();
					oValueHelpDialog.open();
				}.bind(that));
			})
		},

		preferencias: async function () {
			return new Promise((resolve, reject) => {
				var that = this
				this.getView().getModel('renfe_hana').read('/ZrcmpreferenciasinternasSet', {

					success: function (oData, response) {
						//ARRAY
						var datosPREF = oData.results;
						//creacion de la carcasa del modelo
						var oModelNew = new sap.ui.model.json.JSONModel();
						//los datos en el modelo
						oModelNew.setData(datosPREF);
						//append del modelo a la vista
						that.getView().setModel(oModelNew, "jsonPREF");
						resolve(true)
					},
					error: function (oError) {
						resolve(false)
					}
				})
			})
		},

		confirm: function (evento) {
			var i = evento.getParameter("selectedItems").length
			var arrayPlazas = [{
				PLAZA: ""
			}]
			for (var x = 0; x < i; x++) {
				var plaza = {
					PLAZA: ""
				}
				plaza.PLAZA = evento.getParameter("selectedItems")[x].getCells()[0].getProperty("text");
			
				arrayPlazas.push(plaza)
			}
			arrayPlazas.shift()
			console.log(arrayPlazas)

		
		var plazasActuales = this.getView().getModel('jsonSELPREF').getData()
		this.getView().getModel('jsonSELPREF').setData(arrayPlazas.concat(plazasActuales))
		
/*			var oModelNew = new sap.ui.model.json.JSONModel();
			oModelNew.setData(arrayPlazas);

			this.getView().setModel(oModelNew, "jsonSELPREF");*/
		},

		minymax: function () {
			var minVal = this.getView().byId('min').getValue()
			var maxVal = this.getView().byId('max').getValue()
			var datosVisibilidad = this.getView().getModel("jsonVisibilidad").getData();
			if (minVal !== "" && maxVal !== "" && datosVisibilidad.visibleBtnAdd == true) {
				datosVisibilidad.visibleBtnSave = true
				this.getView().getModel("jsonVisibilidad").setData(datosVisibilidad);
			} else {
				datosVisibilidad.visibleBtnSave = false
				this.getView().getModel("jsonVisibilidad").setData(datosVisibilidad)
			}
			
			if (minVal > maxVal){
				MessageBox.error('El numero minimo de plazas no puede ser mayor que el numero maximo')
				this.getView().byId('min').setValue(maxVal) 
								datosVisibilidad.visibleBtnSave = false
				this.getView().getModel("jsonVisibilidad").setData(datosVisibilidad);
				
			}

		},
		onSave: function () {
			var fechasSel = this.getView().byId("DRS2").getValue();
			var jobReqIdSel = this.getView().byId("inputJobReq").getValue();
			var descripcionSel = this.getView().byId("descripcion").getValue();
			var minSel = this.getView().byId("min").getValue();
			var maxSel = this.getView().byId("max").getValue();
			

			var prefSel = this.getView().getModel("jsonSELPREF").getData()
			prefSel.sort()
			var arrayDataBase = []
			var n = -1
			prefSel.forEach((pref) => {
				n++
			var nplazas = pref.NPLAZAS
			//this.getView().byId('tablePref').getRows()[n].getCells()[1].getValue()
				var objPush = {
					"JOBREQID": "",
					"PLAZA": "",
					"FECHAS": "",
					"DESCRIPCION": "",
					"MINVAL": "",
					"MAXVAL": "",
					"NPLAZAS": ""
				}

				objPush.JOBREQID = jobReqIdSel
				objPush.PLAZA = pref.PLAZA.replaceAll(/\s/g, "-");
				//pref.PLAZA.replace(/\s/g, "-")//Te guarda en Base de datos los espacios con '-'
				objPush.FECHAS = fechasSel
				objPush.DESCRIPCION = descripcionSel
				objPush.MINVAL = minSel
				objPush.MAXVAL = maxSel
				objPush.NPLAZAS = nplazas

				arrayDataBase.push(objPush)

			})
			arrayDataBase.forEach((objPush) => {
				var that = this
			
				this.dataBaseRead(objPush).then(function (apto) {
					
					if (apto == false) {
						that.dataBaseCreate(objPush) //No existe registro en Base de datos y hay que crearlo
						
					} else {
						that.dataBaseUpdate(objPush) //Existe el registro en Base de datos y hay que actualizarlo
						
					}
					
				
				
				
			
				})
			})
				MessageBox.success('Convocatoria Añadida/actualizada en Base de Datos')
			//FIN DE FUNCION
		},

		dataBaseUpdate: function (objPush) {

			var pathx = "/ZrcmgrabarpreferenciasSet(JOBREQID='" + objPush.JOBREQID + "',PLAZA='" + objPush.PLAZA + "')"
			this.getView().getModel('renfe_hana').update(pathx, objPush, {
				success: function () {
					console.log('ok')
				},
				error: function (oError) {
					console.log('notok')
				}
			})
			
		//	MessageBox.success('Preferencias para convocatoria: ' + objPush.JOBREQID + ' actualizada')

		},

		dataBaseRead: async function (objPush) {

			return new Promise((resolve, reject) => {
				var pathx = "/ZrcmgrabarpreferenciasSet(JOBREQID='" + objPush.JOBREQID + "',PLAZA='" + objPush.PLAZA + "')"
				this.getView().getModel('renfe_hana').read(pathx, {
					success: function (oData, response) {
						resolve(true)
					},
					error: function (oError) {
						resolve(false)
					}
				})
			})
		},

		dataBaseCreate: function (objPush) {

			var pathx = "/ZrcmgrabarpreferenciasSet"
			this.getView().getModel('renfe_hana').create(pathx, objPush, {
				success: function () {
					console.log('ok')
				},
				error: function (oError) {
					console.log('notok')
				}
			})
			
		//	MessageBox.success('Preferencias para convocatoria: ' + objPush.JOBREQID + ' añadida')

		},

		readDataBaseInitialize: function () {
			var that = this
			this.preferencias().then(function (apto) {
				if (apto == true) {

					that.initializeData().then(function (apto) {
						if (apto == true)
							var oModelNew = new sap.ui.model.json.JSONModel();
						//						arrayPlazasOriginales.shift()
						oModelNew.setData(arrayPlazasOriginales);

						that.getView().setModel(oModelNew, "jsonSELPREF");
						var inputConvocatoriaforMessage = that.getView().byId('inputJobReq').getValue()
						MessageBox.information('Datos de Convocatoria ' + inputConvocatoriaforMessage +  ' recuperados de Base de Datos')

					})
				}
			})

		},

		initializeData: async function () {
			return new Promise((resolve, reject) => {
				var that = this
				var arrayPrefs = this.getView().getModel('jsonPREF').getData()
				var objPush = {
					"JOBREQID": "",
					"PLAZA": ""
				}
				var i = arrayPrefs.length
				var x = 0
				arrayPrefs.forEach((obj) => {
					if (x == 0) {
						arrayPlazasOriginales = []
					}
					x++
					objPush.JOBREQID = that.getView().byId("inputJobReq").getValue()
					objPush.PLAZA =  obj.PLAZA.replaceAll(/\s/g, "-");
									//obj.PLAZA.replace(/\s/g, "")
					

					var pathx = "/ZrcmgrabarpreferenciasSet(JOBREQID='" + objPush.JOBREQID + "',PLAZA='" + objPush.PLAZA + "')"
					that.getView().getModel('renfe_hana').read(pathx, {
						success: function (oData, response) {
							var datosConvocatoria = oData
							that.getView().byId("descripcion").setValue(datosConvocatoria.DESCRIPCION)
							that.getView().byId("DRS2").setValue(datosConvocatoria.FECHAS)
							that.getView().byId("min").setValue(datosConvocatoria.MINVAL)
							that.getView().byId("max").setValue(datosConvocatoria.MAXVAL)
							that.getView().byId("nplazas").setValue(datosConvocatoria.NPLAZAS)

							arrayPlazasOriginales.push({
								"PLAZA": datosConvocatoria.PLAZA.replaceAll("-", " "),
								"NPLAZAS": datosConvocatoria.NPLAZAS
							})
							if (x == i) {
								resolve(true)
							}
						},
						error: function (oError) {
							//	resolve(false)
						}

					})

				})

				//	

			})
		},

		onDelete: function (evento) {
			var plazaEliminada = evento.getSource().getParent().getCells()[0].getText()
			var convocatoriaEscogida = this.getView().byId("inputJobReq").getValue()
			var that = this
			var pathx = "/ZrcmgrabarpreferenciasSet(JOBREQID='" + convocatoriaEscogida + "',PLAZA='" + plazaEliminada + "')"
			var updatedData = []
			this.getView().getModel('renfe_hana').remove(pathx, {
				method: 'DELETE',
				success: function () {
					MessageBox.success('Plaza Eliminada con Exito')
				var data = that.getView().getModel('jsonSELPREF').getData()
					data.forEach((x)=>{
						if(x.PLAZA !==  plazaEliminada)
						updatedData.push(x)
					})
					
					that.getView().getModel('jsonSELPREF').setData(updatedData)
					
				},
				error: function () {
					MessageBox.information('Registro no encontrado en Base de Datos. Se elimina unicamente de la vista')
					var data = that.getView().getModel('jsonSELPREF').getData()
					data.forEach((x)=>{
						if(x.PLAZA !==  plazaEliminada)
						updatedData.push(x)
					})
					
					that.getView().getModel('jsonSELPREF').setData(updatedData)
				}
			})

		}

	});
});